NRaas_SecondImage

[b]THE MOD[/b]

This mod enables the ability to click on the left-hand image of notifications, a pet peeve of mine since it was broken in an long ago EA Patch.

That's it, pretty simple.

[b]WARNINGS[/b]

As always, ensure that you backup your save files prior to installation of this mod. This mod is horribly simple, but if anything can go wrong, it will go wrong.

Have Fun. :D