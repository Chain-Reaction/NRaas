NRaas_NoCD

[b]THE MOD[/b]

This mod disables the scripted portion of the CD authentication check, allowing the game to start without the CD in the drive.

[b]NOTES[/b]

This mod has no effect on the Game Launcher.  You will need to start the game directly, rather than through the launcher.

How to bypass the Launcher : http://www.modthesims.info/wiki.php?title=Game_Help:TS3_Bypassing_the_Launcher

[b]WARNINGS[/b]

As always, ensure that you backup your save files prior to installation of this mod. This mod is horribly simple, but if anything can go wrong, it will go wrong.

Have Fun. :D