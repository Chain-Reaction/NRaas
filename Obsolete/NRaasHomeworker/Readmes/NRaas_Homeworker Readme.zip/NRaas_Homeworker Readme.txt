THE MOD

This mod adds an alarm to the system that fires at 8am each morning, and sets the completion on all inactive homework to a specified value.

By default the value is set to 50%, as I prefer not to give my slacker sims too much of a free ride.

Any inactive sim that actually did complete their homework will be unaffected. The Active household is not affected by this mod.

INSTALLATION

In order to run this mod, you must have the modding Framework properly installed on your system.

Google: Delphy's Framework Install Monkey

NOTES

If you are versed in XML tuning, you can change the kCompletionValue within this mod to whatever percentage you desire.

You can also change the kActiveCompletion to allow the system to complete the homework in the active household.

WARNINGS

As always, ensure that you backup your save files prior to installation of this mod. This mod is horribly simple, but if anything can go wrong, it will go wrong.

Have Fun. :)