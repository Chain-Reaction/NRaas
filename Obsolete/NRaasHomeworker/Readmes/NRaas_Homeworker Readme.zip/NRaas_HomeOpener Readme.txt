NRaas_HomeOpener

THE MOD

This mod forces the game to display the interior contents of every lot in town.

NOTES

The system only loads the interiors if the camera happens to be on the lot.  However doing so will increase the game's memory usage, and may lead to bloatage with extended use.

If you place a new lot, it will not become "open" until you reload the game, or switch to a different household

WARNINGS

As always, ensure that you backup your save files prior to installation of this mod. This mod is horribly simple, but if anything can go wrong, it will go wrong.

Have Fun. :)