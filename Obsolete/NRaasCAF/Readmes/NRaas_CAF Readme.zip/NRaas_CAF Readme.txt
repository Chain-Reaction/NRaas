NRaas_CAF

[b]THE MOD[/b]

This mod changes the "Create Sims" Window in "Edit Town" :
     The restriction that a young adult must be part of the family has been changed to include teenagers
     The "Edit Relationships" window has been adjusted to remove many of the age-restrictions on family links

[b]NOTES[/b]

Do not use this mod in conjunction with Awesome-Core, it will override any changes made by that Core.

Be aware that it is now possible to produce some unorthodox family linkages between sims in the "Edit Relationships" window.  If you find yourself unable to change the linkages for any reason, simply press the Cancel to wipe out the changes and start again.

[b]WARNINGS[/b]

As always, ensure that you backup your save files prior to installation of this mod. This mod is horribly simple, but if anything can go wrong, it will go wrong.

Have Fun. :D