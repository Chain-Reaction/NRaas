NRaas_OpportunityControl

THE MOD

This mod disables the Opportunities for the active sims, ending any automatic opportunities that you may receive.

In addition, it adds a new menu "OpportunityControl" to the computer.

Within this menu are the following new interactions:

"Spawn" : Allows you choose an opportunity to spawn.  All eligible opportunities for the active sim are listed.

"Random" : Randomly chooses a new opportunity from the list of available.  Note, this may not work if you already have an opportunity locked.

"Version" : Displays the version of this mod

NOTES

This mod is compatible with all known mods.

INSTALLATION

In order to run this mod, you must have the modding Framework properly installed on your system.

Google: Delphy's Framework Install Monkey

WARNINGS

As always, ensure that you backup your save files prior to installation of this mod. This mod is horribly simple, but if anything can go wrong, it will go wrong.

Have Fun. :)